let marks = [45, 67, 89, 32, 76, 91, 55, 48, 62, 85];
console.log("Marks:", marks);
let total = 0;

for (let i = 0; i < marks.length; i++) {
    total += marks[i];
}

console.log("Total Marks:", total);
let average = total / marks.length;
console.log("Average Marks:", average);
let highest = Math.max(...marks);
let lowest = Math.min(...marks);

console.log("Highest Marks:", highest);
console.log("Lowest Marks:", lowest);
let passed = 0;
let failed = 0;

for (let i = 0; i < marks.length; i++) {
    if (marks[i] >= 50) {
        passed++;
    }
    else {
        failed++;
    }
}

console.log("Passed Students:", passed);
console.log("Failed Students:", failed);
let grades = marks.map(function(mark) {
    if (mark >= 80) {
        return "A";
    }
    else if (mark >= 70) {
        return "B";
    }
    else if (mark >= 50) {
        return "C";
    }
    else {
        return "Fail";
    }
});

console.log("Grades:", grades);
let passedMarks = marks.filter(function(mark) {
    return mark >= 50;
});

console.log("Passed Marks:", passedMarks);
let ascending = [...marks].sort(function(a, b) {
    return a - b;
});

console.log("Sorted Marks (Ascending):", ascending);
let descending = [...marks].sort(function(a, b) {
    return b - a;
});

console.log("Sorted Marks (Descending):", descending);
let uniqueMarks = [...new Set(marks)];

console.log("Unique Marks:", uniqueMarks);
let searchMark = 67;

if (marks.includes(searchMark)) {
    console.log(searchMark + " is present in the array.");
}
else {
    console.log(searchMark + " is not present in the array.");
}