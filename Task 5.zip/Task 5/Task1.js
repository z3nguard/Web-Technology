let profile = {
    productName: "D13 Smart Watch",
    brand: "D13",
    price: 551,
    color: "Black",
    rating: 4.5,
    reviews: 274,
    deliveryCharges: 160,
    warranty: "No warranty"
};

console.log(profile);