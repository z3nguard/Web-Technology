const choices = ["Rock", "Paper", "Scissors"];

function getComputerChoice() {
    let randomIndex = Math.floor(Math.random() * 3);
    return choices[randomIndex];
}

function determineWinner(player, computer) {
    if (player === computer) {
        return "Draw";
    }
    else if (
        (player === "Rock" && computer === "Scissors") ||
        (player === "Scissors" && computer === "Paper") ||
        (player === "Paper" && computer === "Rock")
    ) {
        return "Player";
    }
    else {
        return "Computer";
    }
}

function playRound(player, computer) {
    console.log("Player:", player);
    console.log("Computer:", computer);

    let winner = determineWinner(player, computer);

    if (winner === "Draw") {
        console.log("Round is a draw!");
    }
    else {
        console.log(winner + " wins the round!");
    }

    return winner;
}

function playMatch() {
    let playerScore = 0;
    let computerScore = 0;

    while (playerScore < 2 && computerScore < 2) {
        let player = choices[Math.floor(Math.random() * 3)];
        let computer = getComputerChoice();

        let winner = playRound(player, computer);

        if (winner === "Player") {
            playerScore++;
        }
        else if (winner === "Computer") {
            computerScore++;
        }

        console.log("Score:", playerScore, "-", computerScore);
        console.log("--------------------");
    }

    if (playerScore === 2) {
        console.log("Player wins the match!");
    }
    else {
        console.log("Computer wins the match!");
    }
}

playMatch();